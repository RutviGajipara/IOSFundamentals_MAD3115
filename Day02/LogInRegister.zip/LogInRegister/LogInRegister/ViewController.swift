//
//  ViewController.swift
//  LogInRegister
//
//  Created by MacStudent on 2018-08-04.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
  
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnLogIn(_ sender: Any) {
        if txtName.text == "Rutvi" && txtPassword.text == "R123"
        {
            var alertController = UIAlertController(title: "Log In", message: "Log In Successful", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            
            self.present(alertController, animated: true, completion: nil)
        }
        else
        {
            var alertControl = UIAlertController(title: "Invalid LogIn", message: "You need to register first..!", preferredStyle: UIAlertControllerStyle.alert)
            alertControl.addAction(UIAlertAction(title: "Register", style: UIAlertActionStyle.default, handler: nil))
            self.present(alertControl, animated: true, completion: nil)
        }
    }
    @IBAction func btnRegister(_ sender: Any) {
        performSegue(withIdentifier: "Register", sender: self)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

