//
//  RegisterViewController.swift
//  LogInRegister
//
//  Created by MacStudent on 2018-08-04.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController {
    @IBAction func normalSegment(_ sender: Any) {
        let segment = sender as! UISegmentedControl
        print("Selected segment : \(segment.selectedSegmentIndex)")
    }

    @IBOutlet weak var DatePicker: UITextField!
    @IBAction func btnDatePicker(_ sender: UITextField) {
        let datePickerView: UIDatePicker = UIDatePicker()
        datePickerView.datePickerMode = UIDatePickerMode.date
        sender.inputView = datePickerView
        datePickerView.addTarget(self, action: #selector(RegisterViewController.datePickerValueChanged), for: UIControlEvents.valueChanged)
    }
    @objc func datePickerValueChanged(_ sender : UIDatePicker)
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = DateFormatter.Style.medium
        
        dateFormatter.timeStyle = DateFormatter.Style.medium
        
        DatePicker.text = dateFormatter.string(for: sender.date)
    }
    
    @IBAction func genderSegment(_ sender: Any) {
        let sgmntBtn = sender as! UISegmentedControl
        switch sgmntBtn.selectedSegmentIndex {
        case 1:
            print("First is selected")
        case 2:
            print("Second id selected")
        default:
            print("Error")
        }
//        if sgmntBtn.selectedSegmentIndex == 1
//        {
//            print("First is selected")
//        }
//        else if sgmntBtn.selectedSegmentIndex == 2
//        {
//             print("Second id selected")
//        }
//        else
//        {
//             print("Error")
//        }
    }
    @IBOutlet weak var txtRPassword: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var txtRName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    @IBAction func btnSignUp(_ sender: Any) {
        var alertController = UIAlertController(title: "Sign Up", message: "Registered Successful", preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                self.present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func btnCancel(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
